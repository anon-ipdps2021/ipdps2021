Overview
========

The Makefile launches experiments and simulations, and then builds all figures
from the paper entitled "Bounding the Flow Time in Online Scheduling with
Structured Processing Sets".

Getting Started
---------------

The code was primarily developed on a debian-like system (Ubuntu 18.04 LTS).
The following version numbers are provided as indication of the versions that
were tested. We recommend to install the default and/or recent versions of
Python and R.

Python scripts were used with the following packages on Python 3.9:

- numba 0.54.0
- numpy 1.20.3
- pandas 1.3.2
- scipy 1.7.1

R scripts were used with the following packages on R 4.1.1:

- dplyr 1.0.7
- ggplot2 3.3.5
- readr 2.0.0
- tidyr 1.1.3
- tikzDevice 0.12.3.1

Recent versions of Python and R can be installed as follows on a
debian-like system (in a shell):

    $ apt install python3 python3-pip r-base

Install all required Python and R packages as follows (around 15
minutes) with `pip` and within R (launched with `R` in a shell):

    $ pip3 install numba==0.54.0 numpy==1.20.3 pandas==1.3.2 scipy==1.7.1
    $ R
    > install.packages(c("dplyr", "ggplot2", "readr", "tidyr", "tikzDevice"))

Finally, Gurobi 9.1.2 needs to be installed. We provide an install script, but
we also explain how to install manually.

First, register with an Academic account on <https://www.gurobi.com/>, and
retrieve an Academic License on
<https://www.gurobi.com/downloads/free-academic-license/>.

### Install script

Launch the install script:

    $ ./install.sh

One needs to provide install paths for Gurobi and the license file (default
values are provided), as well as the license hash given by the Gurobi website.

### Manual install

1. Download Gurobi 9.1.2
   (<https://packages.gurobi.com/9.1/gurobi9.1.2_linux64.tar.gz>).
2. Extract to `<install_dir>` (e.g. `/opt`):
   `tar xzf gurobi9.1.2_linux64.tar.gz -C <install_dir>/`.
3. Install license:
   `<install_dir>/gurobi912/linux64/bin/grbgetkey <your-license>`
   (will be installed in `$HOME/gurobi.lic` by default).
4. Edit `Makefile` with the correct values for `GRB_LICENSE_FILE` and
   `GUROBI_INSTALL`.

### Run simulations

All experiments and simulations can be run with a single call to `make`.
