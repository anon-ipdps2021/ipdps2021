suppressMessages({
	library(readr)
	library(dplyr)
	library(tidyr)
	library(ggplot2)
	library(tikzDevice)
})

MACHINE_COUNT <- 15

args <- commandArgs(trailingOnly = TRUE)

data_load_max <- read_csv("__data__/3_data_load_max.csv.gz", col_types = "iididd")

data_max_lambda <- data_load_max %>%
	pivot_longer(c(lambda_dr, lambda_ndr), names_to = "type", values_to = "max_lambda") %>%
	group_by(m, k, shape, type) %>%
	summarise(max_lambda = median(max_lambda), .groups = "drop")

plot_max_lambda <- ggplot(data_max_lambda %>%
							  mutate(max_lambda = (max_lambda / MACHINE_COUNT) * 100,
									 type = factor(type,
												   levels = c("lambda_ndr", "lambda_dr"),
												   labels = c("Overlapping", "Disjoint"))),
						  mapping = aes(x = k, y = shape, fill = max_lambda)) %+%
	geom_raster() %+%
	facet_wrap(vars(type)) %+%
	scale_x_continuous("Interval size $k$", breaks = seq(1, MACHINE_COUNT, 2)) %+%
	scale_y_continuous("Popularity bias $s$", breaks = seq(0, 5, 1)) %+%
	scale_fill_viridis_c("Max-load (\\%)", option = "magma",
						 guide = guide_colorbar(barwidth = 0.6, barheight = 7.5,
												frame.colour = "black", ticks.colour = "white",
												draw.llim = FALSE, draw.ulim = FALSE)) %+%
	theme(legend.justification = c(0, 0),
		  legend.margin = margin(0, 0, 0, 0),
		  panel.spacing = unit(0.1, "cm"),
		  strip.text = element_text(margin = margin(0.1, 0, 0.1, 0, "cm")))

plot_max_lambda_ratio <- ggplot(data_max_lambda %>%
									pivot_wider(names_from = "type", values_from = "max_lambda"),
								mapping = aes(x = k, y = shape, fill = lambda_ndr / lambda_dr)) %+%
	geom_raster() %+%
	scale_x_continuous("Interval size $k$", breaks = seq(1, MACHINE_COUNT, 2)) %+%
	scale_y_continuous("Popularity bias $s$", breaks = seq(0, 5, 1)) %+%
	scale_fill_viridis_c("Ratio", option = "plasma",
						 guide = guide_colorbar(barwidth = 0.6, barheight = 7.5,
												frame.colour = "black", ticks.colour = "white",
												draw.llim = FALSE, draw.ulim = FALSE)) %+%
	theme(legend.justification = c(0, 0),
		  legend.margin = margin(0, 0, 0, 0))

tikz(file = paste0(args[1], "/3_plot_load_max__max_lambda.tex"), width = 4.2, height = 2)
print(plot_max_lambda)
dev.off()

tikz(file = paste0(args[1], "/3_plot_load_max__max_lambda_ratio.tex"), width = 2.4, height = 2)
print(plot_max_lambda_ratio)
dev.off()
