suppressMessages({
	library(readr)
	library(dplyr)
	library(tidyr)
	library(ggplot2)
	library(tikzDevice)
})

MACHINE_COUNT <- 15

args <- commandArgs(trailingOnly = TRUE)

data_dr_to_ndr <- read_csv("__data__/1_data_dr_to_ndr.csv.gz", col_types = "iiiddcidd")
data_dr_to_ndr_worst_case <- read_csv("__data__/1_data_dr_to_ndr_worst_case.csv.gz", col_types = "iiiddcidd")
data_load_max <- read_csv("__data__/3_data_load_max.csv.gz", col_types = "iididd")
data_load_max_worst_case <- read_csv("__data__/3_data_load_max_worst_case.csv.gz", col_types = "iididd")

data_dr_to_ndr <- data_dr_to_ndr %>%
	group_by(m, k, n, shape, lambda, heuristic) %>%
	summarise(objective_dr = median(objective_dr),
			  objective_ndr = median(objective_ndr), .groups = "drop")

data_dr_to_ndr_worst_case <- data_dr_to_ndr_worst_case %>%
	group_by(m, k, n, shape, lambda, heuristic) %>%
	summarise(objective_dr = median(objective_dr),
			  objective_ndr = median(objective_ndr), .groups = "drop")

data_load_max <- data_load_max %>%
	pivot_longer(c(lambda_dr, lambda_ndr), names_to = "type", values_to = "max_lambda") %>%
	group_by(m, k, shape, type) %>%
	summarise(max_lambda = median(max_lambda), .groups = "drop")

data_load_max_worst_case <- data_load_max_worst_case %>%
	pivot_longer(c(lambda_dr, lambda_ndr), names_to = "type", values_to = "max_lambda") %>%
	group_by(m, k, shape, type) %>%
	summarise(max_lambda = median(max_lambda), .groups = "drop")

data_with_bounds <- data_dr_to_ndr %>%
	pivot_longer(c(objective_dr, objective_ndr), names_to = "type", values_to = "objective") %>%
	mutate(type = ifelse(type == "objective_dr", "dr", "ndr")) %>%
	inner_join(data_load_max %>% mutate(type = ifelse(type == "lambda_dr", "dr", "ndr")),
			   by = c("m", "k", "shape", "type"))

data_with_bounds_worst_case <- data_dr_to_ndr_worst_case %>%
	pivot_longer(c(objective_dr, objective_ndr), names_to = "type", values_to = "objective") %>%
	mutate(type = ifelse(type == "objective_dr", "dr", "ndr")) %>%
	inner_join(data_load_max_worst_case %>% mutate(type = ifelse(type == "lambda_dr", "dr", "ndr")),
			   by = c("m", "k", "shape", "type"))

filtered_data_with_bounds <- bind_rows(data_with_bounds %>%
										   filter(shape %in% c(0, 1), k == 3, heuristic %in% c(0, 1)) %>%
										   mutate(kind = "median"),
									   data_with_bounds_worst_case %>%
										   filter(shape == 1, k == 3, heuristic %in% c(0, 1)) %>%
										   mutate(kind = "worst")) %>%
	mutate(lambda = (lambda / MACHINE_COUNT) * 100,
		   max_lambda = (max_lambda / MACHINE_COUNT) * 100,
		   kind = case_when(kind == "median" & shape == 0 ~ "uniform",
							kind == "median" & shape == 1 ~ "median",
							kind == "worst" ~ "worst")) %>%
	mutate(shape = factor(shape, levels = c(0, 1), labels = c("$s=0$", "$s=1$")),
		   k = "$k=3$",
		   heuristic = factor(heuristic, levels = c(0, 1), labels = c("\\textsc{EFT-Min}", "\\textsc{EFT-Max}")),
		   type = factor(type, levels = c("ndr", "dr"), labels = c("Overlapping", "Disjoint")),
		   kind = factor(kind, levels = c("uniform", "median", "worst"), labels = c("Uniform case", "Shuffled case", "Worst-case")))

plot_dr_to_ndr <- ggplot(filtered_data_with_bounds %>%
							 group_by(m, k, n, shape, heuristic, kind) %>%
							 filter(objective <= 50),
						 mapping = aes(x = lambda, y = objective)) %+%
	geom_line(mapping = aes(linetype = type, color = heuristic),
			  size = 0.5) %+%
	geom_point(mapping = aes(shape = heuristic, color = heuristic),
			   size = 1) %+%
	geom_vline(data = filtered_data_with_bounds %>%
		group_by(m, k, n, shape, type, kind) %>%
		distinct(max_lambda, .keep_all = TRUE),
			   mapping = aes(xintercept = max_lambda, linetype = type),
			   size = 1, color = "red", show.legend = FALSE) %+%
	geom_text(data = filtered_data_with_bounds %>%
		group_by(m, k, n, shape, kind) %>%
		distinct(max_lambda, .keep_all = TRUE),
			  mapping = aes(x = max_lambda, y = 1.5, label = round(max_lambda)),
			  vjust = 0.5, hjust = 1, nudge_x = -1.5, size = 2.5, color = "red") %+%
	facet_wrap(vars(kind, shape), scales = "free_x", labeller = label_wrap_gen(multi_line = FALSE)) %+%
	coord_cartesian(ylim = c(1, 15)) %+%
	scale_x_continuous("Average load (\\%)", n.breaks = 6) %+%
	scale_y_continuous("Max-flow", breaks = seq(1, 15, 2)) %+%
	scale_colour_manual("Heuristic", values = c("#f89540", "#0d0887")) %+%
	scale_shape("Heuristic") %+%
	scale_linetype("Strategy") %+%
	theme(legend.margin = margin(0, 0, 0, 0),
		  panel.spacing = unit(0.1, "cm"),
		  strip.text = element_text(margin = margin(0.1, 0, 0.1, 0, "cm")))

tikz(file = paste0(args[1], "/1_plot_dr_to_ndr.tex"), width = 6.6, height = 2.2)
print(plot_dr_to_ndr)
dev.off()
