suppressMessages({
	library(readr)
	library(dplyr)
	library(tidyr)
	library(ggplot2)
	library(tikzDevice)
})

MACHINE_COUNT <- 15

args <- commandArgs(trailingOnly = TRUE)

data_load_fit <- read_csv("__data__/2_data_load_fit.csv.gz", col_types = "iiddill")

data_max_lambda <- data_load_fit %>%
	pivot_longer(c(fit_dr, fit_ndr), names_to = "type", values_to = "fit") %>%
	filter(fit == TRUE) %>%
	group_by(m, k, shape, permutation, type) %>%
	summarise(max_lambda = max(lambda), .groups = "drop") %>%
	group_by(m, k, shape, type) %>%
	summarise(max_lambda = median(max_lambda), .groups = "drop")

data_min_k <- data_load_fit %>%
	pivot_longer(c(fit_dr, fit_ndr), names_to = "type", values_to = "fit") %>%
	filter(fit == TRUE) %>%
	group_by(m, shape, lambda, permutation, type) %>%
	summarise(min_k = min(k), .groups = "drop") %>%
	group_by(m, shape, lambda, type) %>%
	summarise(min_k = median(min_k), .groups = "drop")

plot_max_lambda <- ggplot(data_max_lambda %>%
							  mutate(max_lambda = max_lambda / MACHINE_COUNT,
									 type = factor(type, levels = c("fit_ndr", "fit_dr"), labels = c("Overlapping", "Disjoint"))),
						  mapping = aes(x = k, y = shape, fill = max_lambda)) %+%
	geom_raster() %+%
	facet_wrap(vars(type)) %+%
	scale_x_continuous("Replication factor $k$", breaks = seq(1, MACHINE_COUNT, 2)) %+%
	scale_y_continuous("Popularity bias $s$", breaks = seq(0, 5, 0.5)) %+%
	scale_fill_viridis_c("Maximum load", option = "magma", guide = guide_colorbar(barwidth = 8, barheight = 1,
																				  frame.colour = "black", ticks.colour = "white",
																				  draw.llim = FALSE, draw.ulim = FALSE)) %+%
	theme(legend.position = "bottom")

plot_max_lambda_ratio <- ggplot(data_max_lambda %>%
									pivot_wider(names_from = "type", values_from = "max_lambda"),
								mapping = aes(x = k, y = shape, fill = fit_ndr / fit_dr)) %+%
	geom_raster() %+%
	scale_x_continuous("Replication factor $k$", breaks = seq(1, MACHINE_COUNT, 2)) %+%
	scale_y_continuous("Popularity bias $s$", breaks = seq(0, 5, 0.5)) %+%
	scale_fill_viridis_c("Max-load ratio", option = "plasma", guide = guide_colorbar(barwidth = 1, barheight = 8,
																					 frame.colour = "black", ticks.colour = "white",
																					 draw.llim = FALSE, draw.ulim = FALSE))

plot_min_k <- ggplot(data_min_k %>%
						 mutate(lambda = (lambda / MACHINE_COUNT) * 100,
								type = factor(type, levels = c("fit_ndr", "fit_dr"), labels = c("Overlapping", "Disjoint"))),
					 mapping = aes(x = lambda, y = shape, fill = min_k)) %+%
	geom_raster() %+%
	facet_wrap(vars(type)) %+%
	scale_x_continuous("Average load (\\%)", n.breaks = 5) %+%
	scale_y_continuous("Popularity bias $s$", breaks = seq(0, 5, 1)) %+%
	scale_fill_viridis_c("Min $k$", guide = guide_colorbar(barwidth = 0.6, barheight = 7.5,
																			 frame.colour = "black", ticks.colour = "white",
																			 draw.llim = FALSE, draw.ulim = FALSE)) %+%
	theme(legend.justification = c(0, 0),
		  legend.margin = margin(0, 0, 0, 0),
		  panel.spacing = unit(0.1, "cm"),
		  strip.text = element_text(margin = margin(0.1, 0, 0.1, 0, "cm")))

# tikz(file = paste0(args[1], "/2_plot_load_fit__max_lambda.tex"), width = 5, height = 3.4)
# print(plot_max_lambda)
# dev.off()
#
# tikz(file = paste0(args[1], "/2_plot_load_fit__max_lambda_ratio.tex"), width = 4, height = 2.65)
# print(plot_max_lambda_ratio)
# dev.off()

tikz(file = paste0(args[1], "/2_plot_load_fit__min_k.tex"), width = 4, height = 2)
print(plot_min_k)
dev.off()
