import numpy as np
import pandas as pd
import numba as nb

from utils import harmonic, getfilename, log, log_line, log_success, log_time_start
from heuristics import max_flow, eft_min, eft_max, eft_rand

H_EFT_MIN, H_EFT_MAX, H_EFT_RAND = 0, 1, 2

if __name__ == "__main__":
    import argparse
    import sys
    import itertools
    import concurrent.futures

    parser = argparse.ArgumentParser()
    parser.add_argument("m", type=int)
    parser.add_argument("n", type=int)
    parser.add_argument("--k-min", type=int, default=1)
    parser.add_argument("--k-max", type=int, default=-1)
    parser.add_argument("--zipf-min", type=int, default=0)
    parser.add_argument("--zipf-max", type=int, default=1)
    parser.add_argument("--zipf-count", type=int, default=3)
    parser.add_argument("--poisson-min", type=int, default=1)
    parser.add_argument("--poisson-max", type=int, default=3)
    parser.add_argument("--poisson-count", type=int, default=3)
    parser.add_argument("--heuristics", type=int, nargs="+", default=[H_EFT_MIN, H_EFT_MAX, H_EFT_RAND])
    parser.add_argument("--worst-case", action="store_true")
    parser.add_argument("-s", "--seed", type=int, default=0)
    parser.add_argument("-i", "--iterations", type=int, default=1)
    parser.add_argument("-p", "--processes", type=int)
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-o", "--out", type=str, default=getfilename(__file__, ".csv.gz"))
    parser.add_argument("--no-out", action="store_true")
    args = parser.parse_args()

    M = args.m
    N = args.n

    MIN_INTERVAL_SIZE = max(1, args.k_min)
    MAX_INTERVAL_SIZE = M if args.k_max < MIN_INTERVAL_SIZE else min(M, args.k_max)
    INTERVAL_SIZES = np.arange(MIN_INTERVAL_SIZE, MAX_INTERVAL_SIZE + 1)

    ZIPF = np.linspace(args.zipf_min, args.zipf_max, num=args.zipf_count)
    POISSON = np.linspace(args.poisson_min, args.poisson_max, num=args.poisson_count)

    HEURISTICS = args.heuristics
    WORST_CASE = args.worst_case

    MIN_SEED = args.seed if args.seed > 0 else 1
    MAX_SEED = args.seed if args.seed > 0 else args.iterations
    SEEDS = np.arange(MIN_SEED, MAX_SEED + 1)


    @nb.njit
    def run(k, s, lmbda, heuristic, seed):
        # First we set the global random generator seed; this will be useful for
        # compiled functions that cannot handle random generator instances such
        # as eft_rand.
        np.random.seed(seed)

        # Pre-compute the Zipf distribution according to parameter `s`; avoid
        # using the standard corresponding function of SciPy
        # (`scipy.stats.zipfian`), which has very bad performance.
        indices = np.arange(1, M + 1)
        weights = 1 / ((indices ** s) * harmonic(M, s))

        # Numba cannot handle random generator instances in nopython-mode; we
        # temporarily use the object-mode to generate our tasks.
        with nb.objmode(tasks_dr="int64[:,:]", tasks_ndr="int64[:,:]"):
            # Initialize a new random generator in order to avoid using the
            # global one, which would be a bad practice for reproducibility.
            rng = np.random.default_rng(seed)

            # If we do not want to study a worst case, we suffle the list of average loads
            # in order to have a more realistic case.
            if not WORST_CASE:
                rng.shuffle(weights)

            # Generate tasks for the disjoint case.
            tasks_dr = np.array([
                np.round(np.cumsum(rng.exponential(1 / lmbda, N))),  # Release times
                np.ones(N),  # Processing times
                ((rng.choice(indices, p=weights, size=N) - 1) // k) * k  # Machine sets
            ]).astype(np.int64)

            # Transform the disjoint instance into another instance where intervals overlap.
            # To do this, we treat each disjoint interval separately; we get all the tasks
            # whose eligibility constraint corresponds to the current interval, and we
            # shift them by a random value weighted according to the Zipf distribution.
            tasks_ndr = tasks_dr.copy()

            for i in range(M // k + min(1, M % k)):
                interval_start = i * k
                interval_len = min(k, M - interval_start)
                interval_weights = weights[interval_start:(interval_start + interval_len)]

                bin_tasks = (tasks_ndr[2] == interval_start).nonzero()[0]
                bin_weights = interval_weights / interval_weights.sum()

                tasks_ndr[2][bin_tasks] += rng.choice(np.arange(0, interval_len), p=bin_weights, size=bin_tasks.size)

        # Generate schedule
        if heuristic == H_EFT_MIN:
            schedule_dr = eft_min(M, k, N, tasks_dr, max_index=M)
            schedule_ndr = eft_min(M, k, N, tasks_ndr)
        elif heuristic == H_EFT_MAX:
            schedule_dr = eft_max(M, k, N, tasks_dr, max_index=M)
            schedule_ndr = eft_max(M, k, N, tasks_ndr)
        elif heuristic == H_EFT_RAND:
            schedule_dr = eft_rand(M, k, N, tasks_dr, max_index=M)
            schedule_ndr = eft_rand(M, k, N, tasks_ndr)
        else:
            raise Exception

        # Compute the max-flow of the generated schedule
        objective_dr = max_flow(tasks_dr, schedule_dr)
        objective_ndr = max_flow(tasks_ndr, schedule_ndr)

        with nb.objmode:
            if args.verbose:
                log_success("OK",
                            f"m={M}, k={k}, n={N}, shape={s}, lambda={lmbda}, heuristic={heuristic}, seed={seed} <objective={objective_dr}/{objective_ndr}>",
                            quiet=args.quiet)

        return objective_dr, objective_ndr


    def getrow(parameters):
        k, s, lmbda, heuristic, seed = parameters
        objective_dr, objective_ndr = run(k, s, lmbda, heuristic, seed)

        return [M, k, N, s, lmbda, heuristic, seed, objective_dr, objective_ndr]


    log("Generating data...", quiet=args.quiet)
    log_time = log_time_start()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.processes) as executor:
        data = executor.map(getrow, itertools.product(INTERVAL_SIZES, ZIPF, POISSON, HEURISTICS, SEEDS))
        df = pd.DataFrame(data, columns=["m", "k", "n", "shape", "lambda", "heuristic", "seed", "objective_dr",
                                         "objective_ndr"])

        log_line(quiet=args.quiet)
        log_success("SUCCESS", "Done.", quiet=args.quiet)
        log_time(quiet=args.quiet)

        if not args.no_out:
            out = sys.stdout if args.out == "stdout" else args.out
            df.to_csv(out, index=False)
            log_success("SUCCESS", f"Written to {args.out}.", quiet=args.quiet)
