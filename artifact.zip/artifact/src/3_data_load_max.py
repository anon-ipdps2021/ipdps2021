import itertools
import ctypes
import numpy as np
import pandas as pd

from utils import harmonic, getfilename, log, log_time_start, log_line, log_success

LIB_LOAD_FIT = ctypes.CDLL("lib/load_max_lp.so")


def solve(m: int, k: int, weights: np.ndarray, relaxation_type=0, debug=0):
    status = ctypes.c_int()
    objective = ctypes.c_double()

    LIB_LOAD_FIT.solve(
        ctypes.c_char(relaxation_type),
        ctypes.c_uint(m),
        ctypes.c_uint(k),
        weights.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        ctypes.byref(status),
        ctypes.byref(objective),
        ctypes.c_char(debug))

    return status.value, objective.value


if __name__ == "__main__":
    import argparse
    import sys
    import concurrent.futures

    parser = argparse.ArgumentParser()
    parser.add_argument("m", type=int)
    parser.add_argument("--zipf-min", type=int, default=0)
    parser.add_argument("--zipf-max", type=int, default=1)
    parser.add_argument("--zipf-count", type=int, default=3)
    parser.add_argument("--permutations", type=int, default=1)
    parser.add_argument("--worst-case", action="store_true")
    parser.add_argument("-s", "--seed", type=int, default=0)
    parser.add_argument("-p", "--processes", type=int)
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-o", "--out", type=str, default=getfilename(__file__, ".csv.gz"))
    parser.add_argument("--no-out", action="store_true")
    args = parser.parse_args()

    M = args.m

    INTERVAL_SIZES = np.arange(1, M + 1)

    ZIPF = np.linspace(args.zipf_min, args.zipf_max, num=args.zipf_count)

    WORST_CASE = args.worst_case

    rng = np.random.default_rng(args.seed)
    PERMUTATIONS = np.arange(args.permutations)
    ORDERS = np.array([rng.permutation(M) for _ in PERMUTATIONS])


    def run(k, s, permutation):
        # Compute the probability mass function of Zipf distribution.
        indices = np.arange(1, M + 1)
        weights = 1 / ((indices ** s) * harmonic(M, s))

        # If we do not want to study a worst case, we suffle the popularity
        # distribution in order to have a more realistic case.
        if not WORST_CASE:
            weights = weights[ORDERS[permutation]]

        # Solve the LP for disjoint case and overlapping case.
        sol_dr = solve(M, k, weights, 0)
        sol_ndr = solve(M, k, weights, 1)

        lambda_dr = sol_dr[1]
        lambda_ndr = sol_ndr[1]

        if args.verbose:
            log_success("OK",
                        f"m={M}, k={k}, shape={s}, <lambda={lambda_dr}/{lambda_ndr}>",
                        quiet=args.quiet)

        return lambda_dr, lambda_ndr


    def getrow(parameters):
        k, s, permutation = parameters
        lambda_dr, lambda_ndr = run(k, s, permutation)

        return [M, k, s, permutation, lambda_dr, lambda_ndr]


    log("Generating data...", quiet=args.quiet)
    log_time = log_time_start()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.processes) as executor:
        data = executor.map(getrow, itertools.product(INTERVAL_SIZES, ZIPF, PERMUTATIONS))
        df = pd.DataFrame(data, columns=["m", "k", "shape", "permutation", "lambda_dr", "lambda_ndr"])

        log_line(quiet=args.quiet)
        log_success("SUCCESS", "Done.", quiet=args.quiet)
        log_time(quiet=args.quiet)

        if not args.no_out:
            out = sys.stdout if args.out == "stdout" else args.out
            df.to_csv(out, index=False)
            log_success("SUCCESS", f"Written to {args.out}.", quiet=args.quiet)
