#include "gurobi_c.h"

#define MIN(a,b) ((a) < (b) ? (a) : (b))

int solve(
	const char relaxation_type,
	const unsigned int machine_count,
	const unsigned int interval_size,
	const double *weights,
	int *status,
	double *objective,
	char debug) {
	GRBenv *env = NULL;
	GRBmodel *model = NULL;

	GRBemptyenv(&env);
	GRBsetintparam(env, "OutputFlag", debug);
	GRBstartenv(env);

	GRBnewmodel(env, &model, "load_max_lp", 0, NULL, NULL, NULL, NULL, NULL);
	GRBsetintattr(model, "ModelSense", GRB_MAXIMIZE);

	// ********************
	// Variable definitions
	// ********************

	// a_ij
	for (unsigned int i = 0; i < machine_count; ++i) {
		for (unsigned int j = 0; j < machine_count; ++j) {
			GRBaddvar(model, 0, NULL, NULL, 0.0, 0.0, GRB_INFINITY, GRB_CONTINUOUS, NULL);
		}
	}

	// lambda
	GRBaddvar(model, 0, NULL, NULL, 1.0, 0.0, machine_count, GRB_CONTINUOUS, NULL);

	// **********************
	// Constraint definitions
	// **********************

	for (unsigned int j = 0; j < machine_count; ++j) {
		unsigned int c0_ind[machine_count + 1];
		double c0_val[machine_count + 1];

		for (unsigned int i = 0; i < machine_count; ++i) {
			c0_ind[i] = i * machine_count + j;
			c0_val[i] = 1.0;
		}

		c0_ind[machine_count] = machine_count * machine_count;
		c0_val[machine_count] = -weights[j];

		GRBaddconstr(model, machine_count + 1, c0_ind, c0_val, GRB_EQUAL, 0.0, NULL);
	}

	for (unsigned int i = 0; i < machine_count; ++i) {
		unsigned int c1_ind[machine_count];
		double c1_val[machine_count];

		for (unsigned int j = 0; j < machine_count; ++j) {
			c1_ind[j] = i * machine_count + j;
			c1_val[j] = 1.0;
		}

		GRBaddconstr(model, machine_count, c1_ind, c1_val, GRB_LESS_EQUAL, 1.0, NULL);
	}

	for (unsigned int i = 0; i < machine_count; ++i) {
		for (unsigned int j = 0; j < machine_count; ++j) {
			unsigned int start = relaxation_type == 0 ? interval_size * (j / interval_size) : j;
			unsigned int end = relaxation_type == 0 ? MIN(machine_count, start + interval_size) : start + interval_size;

			char found = 0;
			for (unsigned int k = start; k < end; ++k) {
				if (k % machine_count == i) {
					found = 1;
					break;
				}
			}

			if (!found) {
				unsigned int c2_ind[1] = {i * machine_count + j};
				double c2_val[1] = {1.0};

				GRBaddconstr(model, 1, c2_ind, c2_val, GRB_EQUAL, 0.0, NULL);
			}
		}
	}

	// ***********
	// Solve model
	// ***********

	GRBoptimize(model);
	GRBgetintattr(model, GRB_INT_ATTR_STATUS, status);
	GRBgetdblattr(model, GRB_DBL_ATTR_OBJVAL, objective);

	GRBfreemodel(model);
	GRBfreeenv(env);

	return 0;
}
