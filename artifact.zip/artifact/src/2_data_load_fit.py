import itertools
import ctypes
import numpy as np
import pandas as pd

from utils import harmonic, getfilename, log, log_time_start, log_line, log_success

LIB_LOAD_FIT = ctypes.CDLL("lib/load_fit_lp.so")


def solve(m: int, k: int, lmbda: float, avg_load: np.ndarray, replication_type=0, debug=0):
    status = ctypes.c_int()
    objective = ctypes.c_double()
    avg_load_fit = np.zeros(m)

    LIB_LOAD_FIT.solve(
        ctypes.c_char(replication_type),
        ctypes.c_uint(m),
        ctypes.c_uint(k),
        ctypes.c_double(lmbda),
        avg_load.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        ctypes.byref(status),
        ctypes.byref(objective),
        avg_load_fit.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        ctypes.c_char(debug))

    return status.value, objective.value, avg_load_fit


if __name__ == "__main__":
    import argparse
    import sys
    import concurrent.futures

    parser = argparse.ArgumentParser()
    parser.add_argument("m", type=int)
    parser.add_argument("--zipf-min", type=int, default=0)
    parser.add_argument("--zipf-max", type=int, default=1)
    parser.add_argument("--zipf-count", type=int, default=3)
    parser.add_argument("--poisson-min", type=int, default=1)
    parser.add_argument("--poisson-max", type=int, default=3)
    parser.add_argument("--poisson-count", type=int, default=3)
    parser.add_argument("--permutations", type=int, default=1)
    parser.add_argument("--worst-case", action="store_true")
    parser.add_argument("-s", "--seed", type=int, default=0)
    parser.add_argument("-p", "--processes", type=int)
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-o", "--out", type=str, default=getfilename(__file__, ".csv.gz"))
    parser.add_argument("--no-out", action="store_true")
    args = parser.parse_args()

    M = args.m

    INTERVAL_SIZES = np.arange(1, M + 1)

    ZIPF = np.linspace(args.zipf_min, args.zipf_max, num=args.zipf_count)
    POISSON = np.linspace(args.poisson_min, args.poisson_max, num=args.poisson_count)

    WORST_CASE = args.worst_case

    rng = np.random.default_rng(args.seed)
    PERMUTATIONS = np.arange(args.permutations)
    ORDERS = np.array([rng.permutation(M) for _ in PERMUTATIONS])


    def run(k, s, lmbda, permutation):
        # Compute the average load of each interval based on the average load of the cluster
        # and the probability mass function of Zipf distribution.
        indices = np.arange(1, M + 1)
        avg_load = lmbda / ((indices ** s) * harmonic(M, s))

        # If we do not want to study a worst case, we suffle the list of average loads
        # in order to have a more realistic case.
        if not WORST_CASE:
            avg_load = avg_load[ORDERS[permutation]]

        # Solve the LP for disjoint case and overlapping case.
        sol_dr = solve(M, k, lmbda, avg_load, 0)
        sol_ndr = solve(M, k, lmbda, avg_load, 1)

        # Check if there is a feasible solution; 2 means that this is the case,
        # whereas 3 indicates a non-feasible model.
        fit_dr = sol_dr[0] == 2
        fit_ndr = sol_ndr[0] == 2

        if args.verbose:
            log_success("OK",
                        f"m={M}, k={k}, shape={s}, lambda={lmbda} <fit={fit_dr}/{fit_ndr}>",
                        quiet=args.quiet)

        return fit_dr, fit_ndr


    def getrow(parameters):
        k, s, lmbda, permutation = parameters
        fit_dr, fit_ndr = run(k, s, lmbda, permutation)

        return [M, k, s, lmbda, permutation, fit_dr, fit_ndr]


    log("Generating data...", quiet=args.quiet)
    log_time = log_time_start()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.processes) as executor:
        data = executor.map(getrow, itertools.product(INTERVAL_SIZES, ZIPF, POISSON, PERMUTATIONS))
        df = pd.DataFrame(data, columns=["m", "k", "shape", "lambda", "permutation", "fit_dr", "fit_ndr"])

        log_line(quiet=args.quiet)
        log_success("SUCCESS", "Done.", quiet=args.quiet)
        log_time(quiet=args.quiet)

        if not args.no_out:
            out = sys.stdout if args.out == "stdout" else args.out
            df.to_csv(out, index=False)
            log_success("SUCCESS", f"Written to {args.out}.", quiet=args.quiet)
