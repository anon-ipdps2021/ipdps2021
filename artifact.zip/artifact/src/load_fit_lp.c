#include "gurobi_c.h"

int solve(
	const char replication_type,
	const unsigned int machine_count,
	const unsigned int replication_factor,
	const double mean_load,
	const double *average_load,
	int *status,
	double *objective,
	double *average_load_fit,
	char debug) {
	GRBenv *env = NULL;
	GRBmodel *model = NULL;

	GRBemptyenv(&env);
	GRBsetintparam(env, "OutputFlag", debug);
	GRBstartenv(env);

	GRBnewmodel(env, &model, "load_fit_lp", 0, NULL, NULL, NULL, NULL, NULL);

	// ********************
	// Variable definitions
	// ********************

	for (unsigned int i = 0; i < machine_count; ++i) {
		GRBaddvar(model, 0, NULL, NULL, 0.0, 0.0, 1.0, GRB_CONTINUOUS, NULL);
	}

	for (unsigned int i = 0; i < machine_count; ++i) {
		for (unsigned int j = 0; j < machine_count; ++j) {
			GRBaddvar(model, 0, NULL, NULL, 0.0, 0.0, 1.0, GRB_CONTINUOUS, NULL);
		}
	}

	// **********************
	// Constraint definitions
	// **********************

	unsigned int c0_ind[machine_count];
	double c0_val[machine_count];

	for (unsigned int i = 0; i < machine_count; ++i) {
		c0_ind[i] = i;
		c0_val[i] = 1.0;
	}

	GRBaddconstr(model, machine_count, c0_ind, c0_val, GRB_EQUAL, mean_load, NULL);

	for (unsigned int i = 0; i < machine_count; ++i) {
		unsigned int c1_ind[machine_count + 1];
		double c1_val[machine_count + 1];

		for (unsigned int j = 0; j < machine_count; ++j) {
			c1_ind[j] = machine_count + i * machine_count + j;
			c1_val[j] = average_load[j];
		}

		c1_ind[machine_count] = i;
		c1_val[machine_count] = -1.0;

		GRBaddconstr(model, machine_count + 1, c1_ind, c1_val, GRB_EQUAL, 0.0, NULL);
	}

	for (unsigned int j = 0; j < machine_count; ++j) {
		unsigned int c2_ind[machine_count];
		double c2_val[machine_count];

		for (unsigned int i = 0; i < machine_count; ++i) {
			c2_ind[i] = machine_count + i * machine_count + j;
			c2_val[i] = 1.0;
		}

		GRBaddconstr(model, machine_count, c2_ind, c2_val, GRB_EQUAL, 1.0, NULL);
	}

	if (replication_type == 0) { // disjoint case
		for (unsigned int i = 0; i < machine_count; ++i) {
			for (unsigned int j = 0; j < machine_count; ++j) {
				if (j < replication_factor * (i / replication_factor) ||
					j > replication_factor * (i / replication_factor) + replication_factor - 1) {
					unsigned int c3_ind[1] = {machine_count + i * machine_count + j};
					double c3_val[1] = {1.0};

					GRBaddconstr(model, 1, c3_ind, c3_val, GRB_EQUAL, 0.0, NULL);
				}
			}
		}
	} else { // non-disjoint case
		for (unsigned int i = 0; i < machine_count; ++i) {
			for (unsigned int j = 0; j < machine_count; ++j) {
				if ((i < replication_factor - 1 && (j > i && j < machine_count + i - replication_factor + 1)) ||
					(i >= replication_factor - 1 && (j > i || j < i - replication_factor + 1))) {
					unsigned int c3_ind[1] = {machine_count + i * machine_count + j};
					double c3_val[1] = {1.0};

					GRBaddconstr(model, 1, c3_ind, c3_val, GRB_EQUAL, 0.0, NULL);
				}
			}
		}
	}

	// ***********
	// Solve model
	// ***********

	GRBoptimize(model);
	GRBgetintattr(model, GRB_INT_ATTR_STATUS, status);
	GRBgetdblattr(model, GRB_DBL_ATTR_OBJVAL, objective);

	for (unsigned int i = 0; i < machine_count; ++i) {
		GRBgetdblattrelement(model, GRB_DBL_ATTR_X, i, average_load_fit + i);
	}

	GRBfreemodel(model);
	GRBfreeenv(env);

	return 0;
}
