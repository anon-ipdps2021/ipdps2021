from typing import *
import numpy as np
import numba as nb

RELEASE_TIME, PROCESSING_TIME, MACHINE_SET = 0, 1, 2
MACHINE_INDEX, START_TIME = 0, 1


@nb.njit
def max_flow(tasks: np.ndarray, schedule: np.ndarray):
    """Compute max flow time of a given schedule."""

    return (schedule[START_TIME] + tasks[PROCESSING_TIME] - tasks[RELEASE_TIME]).max()


@nb.njit
def eft(m: int, k: int, n: int, tasks: np.ndarray, breaktie: Callable, max_index=np.inf):
    """Schedule a set of tasks on m machines according to EFT strategy."""

    times = np.zeros(m, dtype=np.int64)
    schedule = np.full((2, n), -1)

    for task in range(n):
        # Get compatible machines (handle circular intervals if needed)
        machine_set_lb = tasks[MACHINE_SET, task]
        machine_set_ub = min(max_index, tasks[MACHINE_SET, task] + k)
        machine_set = (np.arange(machine_set_lb, machine_set_ub) % m).astype(np.int64)

        # Compute earliest time at which current task will start
        machine_times = times.take(machine_set)
        earliest_time = max(tasks[RELEASE_TIME, task], machine_times.min())

        # Get all machines that are in a tie
        machines = machine_set[machine_times <= earliest_time]

        # Select machine
        machine = breaktie(machines)

        # Update schedule and time
        schedule[MACHINE_INDEX, task] = machine
        schedule[START_TIME, task] = earliest_time
        times[machine] = earliest_time + tasks[PROCESSING_TIME, task]

    return schedule


@nb.njit
def eft_min(m: int, k: int, n: int, tasks: np.ndarray, max_index=np.inf):
    """Schedule a set of tasks according to EFT strategy, choosing the machine with lowest index in case of a tie."""

    def breaktie(machines):
        return machines[0]

    return eft(m, k, n, tasks, breaktie, max_index)


@nb.njit
def eft_max(m: int, k: int, n: int, tasks: np.ndarray, max_index=np.inf):
    """Schedule a set of tasks according to EFT strategy, choosing the machine with highest index in case of a tie."""

    def breaktie(machines):
        return machines[-1]

    return eft(m, k, n, tasks, breaktie, max_index)


@nb.njit
def eft_rand(m: int, k: int, n: int, tasks: np.ndarray, max_index=np.inf):
    """Schedule a set of tasks according to EFT strategy, choosing the machine randomly in case of a tie."""

    def breaktie(machines):
        return np.random.choice(machines)

    return eft(m, k, n, tasks, breaktie, max_index)
