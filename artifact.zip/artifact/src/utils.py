import os
import datetime
import time
import numpy as np
import numba as nb


@nb.njit
def harmonic(n: int, m: float):
    """Compute the `n`-th generalized harmonic number of order `m`.

    More details:
    https://en.wikipedia.org/wiki/Harmonic_number#Generalized_harmonic_numbers
    """

    return (1 / (np.arange(1, n + 1) ** m)).sum()


def getfilename(file: str, ext: str):
    return f"{os.path.basename(file)[:-3]}__{datetime.datetime.today().isoformat()}{ext}"


def blue(_str: str):
    return f"\033[94m{_str}\033[0m"


def green(_str: str):
    return f"\033[92m{_str}\033[0m"


def log(_str: str, quiet=False):
    if not quiet:
        print(_str)


def log_line(width=os.get_terminal_size().columns, quiet=False):
    log('─' * width, quiet)


def log_info(info_str: str, _str: str, quiet=False):
    log(f"[{blue(info_str)}] {_str}", quiet)


def log_success(success_str: str, _str: str, quiet=False):
    log(f"[{green(success_str)}] {_str}", quiet)


def log_time_start():
    start = time.time()

    def log_time(quiet=False):
        end = time.time()
        log_info("INFO", f"Took {end - start} seconds.", quiet)

    return log_time
