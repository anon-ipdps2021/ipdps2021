#!/bin/bash

FILE_GZ=gurobi9.1.2_linux64.tar.gz

read -e -p "Enter the path to the install directory [/opt]: " INSTALL_DIR

INSTALL_DIR=${INSTALL_DIR:-/opt}
INSTALL_DIR_SLASH="${INSTALL_DIR%/}/"

wget https://packages.gurobi.com/9.1/$FILE_GZ
tar xzf $FILE_GZ -C $INSTALL_DIR_SLASH
rm $FILE_GZ

read -e -p "Enter the path to the license directory [$HOME]: " GRB_LICENSE_DIR

GRB_LICENSE_DIR=${GRB_LICENSE_DIR:-$HOME}

read -e -p "Enter your Gurobi license: " GRB_LICENSE

$INSTALL_DIR/gurobi912/linux64/bin/grbgetkey $GRB_LICENSE --path $GRB_LICENSE_DIR

sed -i -E "s/^GRB_LICENSE_FILE = .+/GRB_LICENSE_FILE = ${GRB_LICENSE_DIR//\//\\/}\\/gurobi.lic/g" Makefile
sed -i -E "s/^GUROBI_INSTALL = .+/GUROBI_INSTALL = ${INSTALL_DIR//\//\\/}/g" Makefile

